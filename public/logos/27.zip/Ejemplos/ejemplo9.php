<?php

//arrays

$marcas = []; //array()
$marcas[] = 'Opel'; //0
$marcas[] = 'Seat'; //1
$marcas[3] = 'BMW'; //3
$marcas[] = 'Nissan'; //4
$marcas['Vecino'] = 'Ford';
$marcas[] = 'Mercedes';
unset($marcas[5]);
//0-Opel, 1-Seat, 3-BMW, 4-Nissan, Vecino-Ford
//$marcas[5] = null;

foreach($marcas as $marca) {
    echo "$marca<br>";
}

//0-Opel, 1-Seat, 3-BMW, 4-Nissan, Vecino-Ford
//0-0,1-1,2-3,3-4,4-Vecino
$marcas2 = array_keys($marcas);

foreach($marcas2 as $indice => $marca) {
    echo "$indice $marca<br>";
    //if($marca === 'Ford'){
    //    echo 'La posición de Ford es: ' . $indice;
    //}
}