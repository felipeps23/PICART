<?php 

//Dar un valor predeterminado de forma flexible

function read(String $str, String $vlr = ''){
    $v = $vlr;
    if(isset($_GET[$str])){
        $v = $_GET[$str];
    }else if(isset($_POST[$str])){
        $v = $_POST[$str];
    }
    return $v;
}

$a = read('a');
echo $a;

echo '<br>'; 

$b = read('ba', 'abcd');
echo $b;

