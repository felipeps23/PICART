<!doctype html>
<!-- así no se hacen las cosas -->
<!--
En PHP hay dos arrays constantes (asociativo) en los que me llegan los valores que han viajado a través de internet.

$_GET  - todos los valores enviados por GET

$_POST - todos los valores enviados por POST

$_REQUEST - todos los valores enviados por GET, POST y las COOKIES -> resumen es un follón, está desaconsejado su uso

-->
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Document</title>
    </head>
    <body>
        <h1>Los valores que se han introducido son:</h1>
        <h2>
            Nombre de la persona:
            <br />
<b>Notice</b>:  Undefined index: nombre in <b>/var/www/html/ejemplos/ejemplo4.php</b> on line <b>27</b><br />
        </h2>
        <h2>
            Vehículos de la persona:
            <br />
<b>Notice</b>:  Undefined index: cars in <b>/var/www/html/ejemplos/ejemplo4.php</b> on line <b>34</b><br />
<br />
<b>Warning</b>:  Invalid argument supplied for foreach() in <b>/var/www/html/ejemplos/ejemplo4.php</b> on line <b>36</b><br />
        </h2>
    </body>
</html>