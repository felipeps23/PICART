<?php 

$nombre = 'mundo';

echo 'Hola ' . $nombre;

?>
<br>

<?php

echo "Hola $nombre";

echo '<br>';

echo "Hola " . $nombre;

?>
<h1>Hola mundo</h1>

<h1>Hola <?= $nombre ?></h1>

<h1>Hola <?php echo $nombre; ?></h1>