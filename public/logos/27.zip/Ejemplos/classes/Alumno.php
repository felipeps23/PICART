<?php

class Alumno{

    //Son static, no se declaran static, porque ya son static por defecto
    const CURSO = '2DWES A';
    private static $modulo;
    private $nombre, $apellidos, $correo;
    
    //Constructor
    
    function __contruct($nombre, $apellidos = '', $correo = null){
        $this->nombre = $nombre;
        $this->apellidos = $apellidos;
        $this->correo = $correo;
    }
    
    function getNombre(){
        // ->
        return $this->nombre;
    }
    
    function getApellidos(){
        return $this->apellidos;
    }
    
    function getCorreo(){
        return $this->correo;
    }
    
    static function getModulo(){
        //return Alumno::modulo;
        return self::modulo;
    }
    
    function setNombre(string $nombre){
        $this->nombre = $nombre;
        return $this;
    }
    
    function setApellidos(string $apellidos){
        $this->apellidos = $apellidos;
        return $this;
    }
    
    function setCorreo(string $correo){
        $this->correo = $correo;
        return $this;
    }
    
    static function setModulo(string $modulo){
        self::$modulo = $modulo;
        return self::$modulo;
    }
    
    //to String
    function __toString(){
        return $this->nombre . ' ' . $this->apellidos . ' ' . $this->correo;
    }
}