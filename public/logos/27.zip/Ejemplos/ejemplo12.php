<?php

include 'classes/Alumno.php';
//include ('classes/Alumno.php');
//require ('classes/Alumno.php');
//require 'classes/Alumno.php';

$alumno = new Alumno('Pepe');

echo $alumno;